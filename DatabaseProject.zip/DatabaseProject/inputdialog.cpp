#include "inputdialog.h"
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QHeaderView>
#include <QGroupBox>
#include "addinfo.h"
#include <QDebug>
#include <QSqlError>
extern QSqlDatabase db;
InputDialog::InputDialog(QWidget* parent)
    :QWidget(parent)
{
    QVBoxLayout *mainLayout = new QVBoxLayout();
    QHBoxLayout *controlLayout = new QHBoxLayout();
    QGroupBox *groupBox = new QGroupBox("Income");

    groupBox->setLayout(mainLayout);
    _addRecordBtnPtr = new QPushButton("Add");
    _removeRecordBtnPtr = new QPushButton("Remove");
    _editRecordBtnPtr = new QPushButton("Edit");

    connect(_addRecordBtnPtr, SIGNAL(clicked()), this, SLOT(addNewRecord()));
    connect(_editRecordBtnPtr, SIGNAL(clicked()), this, SLOT(editRecord()));
    connect(_removeRecordBtnPtr, SIGNAL(clicked()), this, SLOT(deleteRecord()));

    controlLayout->addStretch();
    controlLayout->addWidget(_addRecordBtnPtr);
    controlLayout->addWidget(_removeRecordBtnPtr);
    controlLayout->addWidget(_editRecordBtnPtr);

    mainLayout->addLayout(controlLayout);


    _tableView = new QTableView();
    _model = new TableModel();
    _tableView->setModel(_model);
    _tableView->horizontalHeader()->show();
    _tableView->verticalHeader()->hide();
    _tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    _tableView->setAlternatingRowColors(true);
    _tableView->horizontalHeader()->setStretchLastSection(true);
    _tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    _tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    QFont font = _tableView->horizontalHeader()->font();
    font.setBold(true);
    _tableView->horizontalHeader()->setFont(font);
    mainLayout->addWidget(_tableView);

    QHBoxLayout *groupedLayout = new QHBoxLayout();
    groupedLayout->addWidget(groupBox);
    setLayout(groupedLayout);
}


void InputDialog::addNewRecord()
{
    AddInfo infoDialog;
    if(infoDialog.exec())
    {
        IncomeRecord record;
        record.category = infoDialog.getCategory();
        record.amount = infoDialog.getAmount();
        record.date = QDateTime::currentDateTime();
        record.description = infoDialog.getDescription();

        QAbstractItemModel* model = _tableView->model();
        ChangeNotifier* notifier = dynamic_cast<ChangeNotifier*>(model);
        if(notifier)
            notifier->addRecord(record);
    }
}

void InputDialog::editRecord()
{
    QModelIndexList selectionList = _tableView->selectionModel()->selectedRows();
    if(selectionList.count() != 1)
        return;

    AddInfo infoDialog;
    QAbstractItemModel* aModel = _tableView->model();
    TableModel *model = dynamic_cast<TableModel*>(aModel);
    IncomeRecord record ;
    if(model)
    {
        record = record = model->getIncomeRecord(selectionList[0].row());
        if(record.id != -1)
        {
            infoDialog.setCategory(record.category);
            infoDialog.setAmount(record.amount);
            infoDialog.setDescription(record.description);
        }
    }
    else
        return;

    if(infoDialog.exec())
    {
        record.category = infoDialog.getCategory();
        record.amount = infoDialog.getAmount();
        record.description = infoDialog.getDescription();

        ChangeNotifier* notifier = dynamic_cast<ChangeNotifier*>(aModel);
        if(notifier)
            notifier->modify(record);
    }
}

void InputDialog::deleteRecord()
{
    QModelIndexList selectionList = _tableView->selectionModel()->selectedRows();
    if(selectionList.count() != 1)
        return;

    QAbstractItemModel* aModel = _tableView->model();
    TableModel *model = dynamic_cast<TableModel*>(aModel);
    IncomeRecord record ;
    if(model)
    {
        record = model->getIncomeRecord(selectionList[0].row());
        if(record.id != -1)
        {
            ChangeNotifier* notifier = dynamic_cast<ChangeNotifier*>(aModel);
            if(notifier)
                notifier->deleteRecord(record.id);
        }
        else
            return;
    }
}

TableModel::TableModel()
{
    retriveData();
    connect(this, SIGNAL(modelReset()), this, SLOT(retriveData()));
}

void TableModel::retriveData()
{
    query.exec("SELECT id, category, amount, description, date from Income");

    _recordVec.clear();

    IncomeRecord record;
    while(query.next())
    {
         record.id = query.value(0).toInt();
         record.category = query.value(1).toString();
         record.amount = query.value(2).toFloat();
         record.description = query.value(3).toString();
         record.date = query.value(4).toDateTime();

         _recordVec.append(record);
    }

}

int TableModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
    return _recordVec.count();
}

int TableModel::columnCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
    return 4;
}

QVariant TableModel::data(const QModelIndex &index, int role) const
{
    if(role == Qt::TextAlignmentRole)
    {
        return Qt::AlignCenter;
    }
    if(role == Qt::DisplayRole)
    {
        if(index.column() == 0)
        {
            if(index.row() >= _recordVec.count())
                return QVariant();
            else
                return _recordVec[index.row()].category;
        }
        if(index.column() == 1)
        {
            if(index.row() >= _recordVec.count())
                return QVariant();
            else
                return _recordVec[index.row()].amount;
        }
        if(index.column() == 2)
        {
            if(index.row() >= _recordVec.count())
                return QVariant();
            else
                return _recordVec[index.row()].description;
        }
        if(index.column() == 3)
        {
            if(index.row() >= _recordVec.count())
                return QVariant();
            else
                return _recordVec[index.row()].date.toString("d-MMMM-yyyy");
        }

    }
    return QVariant();
}

QVariant TableModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    if(orientation == Qt::Horizontal && role == Qt::DisplayRole)
    {
        switch(section)
        {
        case 0:
            return QString("Category");
        case 1:
            return QString("Amount");
        case 2:
            return QString("Decription");
        case 3:
            return QString("Date");
        default:
            return QVariant();
        }
    }
    return QVariant();
}

void TableModel::addRecord(IncomeRecord record)
{
    beginResetModel();
    query.prepare("INSERT INTO Income(category, amount, description, date)"
                   "VALUES(:category, :amount, :description, :date)");
    query.bindValue(":category", record.category);
    query.bindValue(":amount", record.amount);
    query.bindValue(":description", record.description);
    query.bindValue(":date", QDateTime::currentDateTime());
    query.exec();

    endResetModel();
}

void TableModel::modify(IncomeRecord record)
{
    beginResetModel();
    query.prepare("UPDATE Income set category = :category, amount = :amount, description = :description "
                  "where id=:id");
    query.bindValue(":category", record.category);
    query.bindValue(":amount", record.amount);
    query.bindValue(":description", record.description);
    query.bindValue(":id", record.id);

    query.exec();

    endResetModel();
}

void TableModel::deleteRecord(int id)
{
    beginResetModel();
    query.prepare("DELETE from Income where id = :id");
    query.bindValue(":id", id);
    query.exec();
    endResetModel();
}

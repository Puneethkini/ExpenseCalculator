#ifndef INPUTDIALOG_H
#define INPUTDIALOG_H

#include <QWidget>
#include <QTableView>
#include <QAbstractTableModel>
#include <QSqlQuery>
#include <QDateTime>
#include <QPushButton>
#include <QSqlDriver>
class TableModel;
class InputDialog : public QWidget
{
    Q_OBJECT
public:
    InputDialog(QWidget *parent = 0);
public slots:
    void addNewRecord();
    void editRecord();
    void deleteRecord();
private:
    QPushButton *_addRecordBtnPtr;
    QPushButton *_removeRecordBtnPtr;
    QPushButton *_editRecordBtnPtr;
    QTableView *_tableView;
    TableModel *_model;
};

struct IncomeRecord
{
    IncomeRecord():id(-1), amount(0) {}
    int id;
    QString category;
    float amount;
    QString description;
    QDateTime date;
};

class ChangeNotifier
{
public:
    virtual void addRecord(IncomeRecord record) = 0;
    virtual void deleteRecord(int id) = 0;
    virtual void modify(IncomeRecord record) = 0;
};

class TableModel : public QAbstractTableModel, public ChangeNotifier
{
    Q_OBJECT
public:
    TableModel();
    IncomeRecord getIncomeRecord(int rowNum)
    {
        if(rowNum >= _recordVec.size())
            return IncomeRecord();
        return _recordVec[rowNum];
    }

protected:
    int rowCount(const QModelIndex &parent) const;
    int columnCount(const QModelIndex &parent) const;
    QVariant data(const QModelIndex &index, int role) const;
    QVariant headerData(int section, Qt::Orientation orientation, int role) const;

    void addRecord(IncomeRecord record);
    void modify(IncomeRecord record);
    void deleteRecord(int id);
private slots:
    void retriveData();
private:
    QSqlQuery query;
    QVector<IncomeRecord> _recordVec;
};

#endif // INPUTDIALOG_H

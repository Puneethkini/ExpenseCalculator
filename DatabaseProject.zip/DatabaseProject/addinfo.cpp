#include "addinfo.h"
#include <QGridLayout>
#include <QDateTimeEdit>
#include <QRegularExpression>
AddInfo::AddInfo(QWidget *parent) :
    QDialog(parent)
{
    _categoryLabel = new QLabel("Category");
    _categoryEdit = new QLineEdit("Income category");
    _amountLabel = new QLabel("Amount");
    _amountEdit = new QLineEdit("0.0");
    _validator = new QDoubleValidator(0.00, 1000000.00, 2);
    _amountEdit->setValidator(_validator);
    _categoryEdit->setPlaceholderText(QString("Enter something"));

    _descriptionLabel = new QLabel("Description");
    _descriptionEdit = new QLineEdit("Description");
    _descriptionEdit->setMaxLength(20);

    _acceptButton = new QPushButton("Save");
    _rejectButton = new QPushButton("Reject");

    connect(_acceptButton, SIGNAL(clicked()), this, SLOT(saveIncome()));
    connect(_rejectButton, SIGNAL(clicked()), this, SLOT(reject()));

    QGridLayout *grid = new QGridLayout;
    grid->addWidget(_categoryLabel, 0, 0);
    grid->addWidget(_categoryEdit, 0, 1);
    grid->addWidget(_amountLabel, 1, 0);
    grid->addWidget(_amountEdit, 1, 1);
    grid->addWidget(_descriptionLabel, 2, 0);
    grid->addWidget(_descriptionEdit, 2, 1);
    grid->addWidget(_acceptButton, 3, 0);
    grid->addWidget(_rejectButton, 3, 1);

    setLayout(grid);
}

void AddInfo::saveIncome()
{
    if(_categoryEdit->text().isEmpty())
    {
        QPalette pal = _categoryLabel->palette();
        pal.setColor(QPalette::WindowText, Qt::red);
        _categoryLabel->setPalette(pal);
        _categoryLabel->setText(_categoryLabel->text());
        return;
    }
    accept();
}

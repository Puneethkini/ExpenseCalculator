#include "mainwindow.h"
#include "inputdialog.h"
#include <QApplication>
#include <QtSql/QSqlDatabase>
#include <QMessageBox>
#include <QtSql/QSqlError>
#include <QtSql/QSqlQuery>
#include <QDebug>
#include <QDateEdit>

QSqlDatabase db;
bool createConnection()
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:/SQLite/sqlite-tools-win32-x86-3240000/ExpenseCalculator.db");
    if(!db.open())
    {
        QMessageBox::critical(0, QObject::tr("Database Error"),
                              db.lastError().text());
        return false;
    }
    return true;
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    /*MainWindow w;
    w.show();*/
    if(!createConnection())
    {
        qDebug()<<"failed to open an db connection";
        // create a class that will insert records in to Expense table created
        // create a function in the class that will retrive all the records
        // create a function that will list only the top 10 and the middle 10.
        // create a function that will tell me the total number of rows
        // document the process of installing SQLite and running essential commands on it
        return 1;
    }
    else
    {
        qDebug()<<"Sucessfully opened an db connection";
    }
    InputDialog dialog;
    dialog.setFixedWidth(500);
    dialog.show();
    return a.exec();
}

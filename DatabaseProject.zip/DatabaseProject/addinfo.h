#ifndef ADDINFO_H
#define ADDINFO_H

#include <QDialog>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QSqlQuery>
#include <QDoubleValidator>
class AddInfo : public QDialog
{
    Q_OBJECT
public:
    explicit AddInfo(QWidget *parent = 0);
    QString getCategory()
    {
        return _categoryEdit->text();
    }

    float getAmount()
    {
        return _amountEdit->text().toFloat();
    }

    QString getDescription()
    {
        return _descriptionEdit->text();
    }

    void setCategory(QString category)
    {
        _categoryEdit->setText(category);
    }

    void setAmount(float amount)
    {
        _amountEdit->setText(QString::number(amount));
    }

    void setDescription(QString desc)
    {
        _descriptionEdit->setText(desc);
    }

signals:
    
public slots:
    void saveIncome();
private:
    QLabel *_categoryLabel;
    QLabel *_amountLabel;
    QLabel *_descriptionLabel;
    QLineEdit *_categoryEdit;
    QLineEdit *_amountEdit;
    QLineEdit *_descriptionEdit;
    QPushButton *_acceptButton;
    QPushButton *_rejectButton;
    QDoubleValidator *_validator;
};

#endif // ADDINFO_H
